NIOH 3 ENGINE FIX - ROG Ally (Bazzite / Proton) quick install
=============================================================
Game version: Steam v2.02 only. The mod checks the game version and does nothing on any other build.
FIRST TEST EVER on real hardware: this mod has never been run in-game before (Smart App Control blocked it on
the PC it was built on). Please report what happens.

FILES IN THIS ZIP
  dinput8.dll              Ultimate ASI Loader (the same file Lyall's Nioh3Fix ships). Loads .asi mods.
  Nioh3EngineFix.asi       the engine fixes
  Nioh3EngineFix.ini       its settings (1 = on, 0 = off)
  shader\0x0104840c.file   OPTIONAL faster shadow shader (same look, less GPU time)
  README-MOD.md            full documentation

1) FIND THE GAME FOLDER on Bazzite
   Desktop Mode -> Steam -> right-click Nioh 3 -> Manage -> Browse local files.
   (Usually ~/.local/share/Steam/steamapps/common/Nioh3 - the folder with Nioh3.exe in it.)

2) COPY into that folder (next to Nioh3.exe):
   dinput8.dll, Nioh3EngineFix.asi, Nioh3EngineFix.ini
   If you already use Nioh3Fix, its dinput8.dll is the same loader - keep only one.

3) STEAM LAUNCH OPTIONS (right-click Nioh 3 -> Properties -> Launch options):
   WINEDLLOVERRIDES="dinput8=n,b" %command%
   (Without this, Proton ignores the loader and the mod never runs.)

4) OPTIONAL fast shadow shader:
   In the game folder open shader_dx12\. First COPY the original 0x0104840c.file somewhere safe (backup).
   Then copy shader\0x0104840c.file from this zip over it. To undo: put the backup back, or Steam ->
   Properties -> Installed Files -> Verify integrity.

5) IN-GAME SETTINGS
   - Set "FPS dynamic adjustment" to OFF (required with the mod's frame-timing fix; otherwise the game keeps
     dropping into its 60 fps mode).
   - Pick the FPS cap you can mostly hold (30 or 60 on the Ally). With the fix the game runs at real speed
     even below the cap, so no slow-motion.
   - Frame generation on Linux/Deck: community reports say turning it on can crash the game until its config
     file is deleted - leave it OFF on Bazzite for now. (Your config.xml had FRAME_GENERATION=OFF: that is why FG
     never ran - nothing else was blocking it. The startup popup and the mod menu now say this.)

6) ON-SCREEN OVERLAY (new, 2026-10-07)
   Top-left: FPS (frames the game renders and presents) | FG FPS (frames shown incl. frame generation, or "FG: off"),
   "(game N Hz)" is added when the engine updates more often than it presents (that was the old "Real FPS"),
   plus real frame time and the game-speed factor (1.00x = real time).
   About 3 s after the game starts rendering, a status panel shows for ~8 s: "Nioh3EngineFix ... loaded - N/N fixes
   active" (green, or yellow with what was skipped), frame generation state, VRR/cap, an orange warning if
   "FPS dynamic adjustment" is ON, and the Proton / L1 / F1 state.
   Turn off in the ini: [Overlay] FpsCounter = 0 and [General] StartupPopup = 0.
   If it doesn't appear, the log says why (lines starting with "OSD").

7) MOD MENU (new)
   Open anytime: HOLD the Start/Menu button for 5 seconds (a countdown shows top-right), or F10 on a keyboard.
   Inside: D-pad / left stick to move, Left/Right to change values, A to toggle, B to close (or hold Start 5 s).
   While the menu is open the game ignores the controller. In the game's own pause menu a top-right reminder
   shows "Hold Start 5s: Mod menu". Every live fix can be switched on/off; "Save to ini" keeps your choices.
   Items marked "* restart" (WorkerCap, P12, L1/F1 on Proton) apply on the next launch.
   GAME SETTING rows: "Frame generation" = the game's FG setting, "FG running" = whether generated frames reach the
   screen (real vs presented fps), "Upscaler" = the game's upscaler setting; an orange line says why FG isn't running.
   Under Proton the FG row is read-only by default (FG is reported to crash there). To test FG anyway, set
   [Menu] FrameGenToggle = 2 in the ini: the switch then works for the session only and is never saved, so a crash
   is undone by simply restarting the game. While FG is on, don't change other options in the game's own menu.

8) IS IT WORKING?
   After launching once, open Nioh3EngineFix.log in the game folder. It lists every patch: "applied" or
   "SKIPPED" with the reason. Send me that log.

EXPERIMENTAL CPU-POWER PATCHES (v1.1.0+) - A/B them for watts
   The Ally is power-bound: CPU + GPU share ~25 W, so every CPU watt saved lets the GPU clock higher. These patches
   cut CPU work inside the game. W6 is confirmed on the Ally (main thread 98% -> 23%, GPU 1064 -> 1450 MHz,
   +7-12% fps); the others are new and not yet tested in-game - A/B each one and report.
   In this zip's ini: W6 = 1, GF = 1, TS = 1, WakeStats = 1, ED = 2 (installed, off), [GpuOpt] Barriers = 2 (hooked,
   off), v1.6.0: WG = 2, CP = 2, SPF = 2 (installed, off); IK = 0, TG = 0, DS = 0, LK = 0 and all other
   experimental keys are 0. To try another one, set it to 1 in
   the ini (or in the mod menu: A on its row -> "* restart", Save to ini) and restart.
   Once installed, W6 B PP FPC AABB M1 X1 E1 IK TS switch ON/OFF live in the mod menu (no restart). M2 J1 S1 only
   at launch.
     W6   main thread sleeps while Present blocks instead of Sleep(0)-spinning a core   (confirmed, keep it on)
     B    draw-list search (main thread)            PP   page-pool sweep every 4th frame (main thread)
     FPC  material lookup cache (main thread)       AABB bounding-box math in SSE (game update thread)
     M1   meshlet worker cache (workers)            X1   skip empty pad slots (input thread)
     E1   hidden effects update every 2nd pass      M2/J1  plain loads in worker polls      S1  pause in a spin

INPUT LATENCY (v1.2.0)
     IK   the game reads the pad at the START of each logic frame instead of the end of the previous one. Your v6 run
          showed no gain here (the Ally is GPU-bound, so the input was already fresh) - off in this zip. It no longer
          waits for the read at the frame start (v6 lost ~2 ms of logic-thread time per frame there). Same image, still one pad read per frame. Toggle it while not
          pressing anything: the frame you switch it on reads the pad twice.
     TS   timestamps inside the game (measurement only). Its menu row (INPUT LATENCY > TS input -> display) shows the
          median time from the pad read to the frame being presented, in ms. Add about 4 ms (half a 120 Hz refresh)
          for the middle of the screen. The log has a "stats latency" line every 30 s with every stage.
     Max frame latency (LIVE FIXES row): game = the game's own value (1), 2/3 = more frames queued. This zip: game.
          Under Proton a LOWER value only applies after the swapchain is rebuilt or the game restarts - so to compare,
          set it in the ini ([Latency] MaxFrameLatency) and restart.

MEMORY LINE + HANDLE FIX (v1.5.0)
     MemStats  on in this zip: the log gets a "stats mem:" line every 30 s (working set, handles, threads, GPU memory,
               change since start). For the leak tests: note it after each load / fast travel.
     WL        closes a handle the game leaks every frame on Windows. Under Proton it never triggers (the line
               "stats/s WL" stays at 0) - nothing to test on the Ally.
GPU FENCE WAITS (v1.4.0) - test this next, it may be the biggest CPU-watt item left
     GF   your profiler run found the main thread spending 58 % of its time in a Sleep(0) loop that waits for the GPU
          to finish. GF lets it sleep on the GPU fence's event instead (the same signal the game uses elsewhere).
          On in this zip; A/B it live in the mod menu (GPU FENCE WAITS). The log's "stats/s GF" line shows the waits
          per second, the average wait and any fallbacks (should be 0). Watch the main-thread CPU %, CPU W, GPU MHz.
WORKER WAKES + GPU (v1.3.0)
     WakeStats  counters only: the log line "stats wakes/s" every 30 s shows how often the game wakes its worker
                threads (per wake site), how often they go back to sleep (per pool) and a "wasted" estimate.
     ED         effect workers with nothing to update are not woken. Same picture. Off in this zip (ED = 2 =
                ready); switch it ON in the mod menu (WORKER WAKES) for the A/B.
     GPU barrier batching (GPU section of the menu): Barriers = 2 = hooked, off. Switch it ON for an A/B; the
                "GPU:" row and the log's "stats/s gpuopt" line show the barrier counts. Expected ~0 on the Ally.
NEW IN v1.6.0 (v10) - all opt-in, A/B them live in the mod menu, section "1.6.0 - OPT-IN"
     WG   wake gate: the game no longer wakes a second job worker while one it just woke is still on its way (that one
          checks every queue of the pool right after waking, so no job is left behind - see README-MOD.md, WG).
          Targets the wake storms in the first minutes after loading into a level. This zip: WG = 2 (installed, OFF).
          Log: "stats/s WG" (wakes skipped / counted per second). WakeStats stays on for the "stats wakes/s" line.
     CP   collision workers prefetch the next colliders; SPF  the stage-update worker prefetches placeables ahead.
          Same results, fewer memory stalls on the worker threads. This zip: CP = 2, SPF = 2 (installed, OFF).
     LK   18 locked loads in worker code become plain loads. Code bytes: set LK = 1 in the ini and restart. 0 here.
     TG   EXPERIMENT (off here, TG = 0): the game logic runs as many ticks per second as you see frames (floor 30)
          instead of up to the in-game cap. Your MAX run computed 44.6 logic ticks/s for 16.2 shown fps. The logic
          step becomes 1/30 s like the game's own 30 FPS mode; a button tap must be held ~33 ms instead of ~22 ms to
          count (normal taps are longer). TG needs L1, and under Proton L1 is only installed with L1OnWine = 1 (0 in
          this zip). Without it the TG row says "REFUSED: L1 off" and nothing changes.
     DS   (off here) sleeps inside the main thread's 1 ms "no new frame yet" retry loop. Only useful together with TG;
          also needs L1 (L1OnWine = 1). Set DS = 2 to have it installed for a live A/B.
   v1.6.0 A/B recipes (same fixed spot, MangoHud CPU W / GPU MHz / fps, 20 s per leg, OFF/ON 3 times):
     WG.  Load into a level, and right after the loading screen: menu -> WG ON for the first ~2 minutes, then repeat
          the load with WG OFF. Compare "stats/s WG" and "stats wakes/s" (wake-one 48C6B, wasted), CPU W and fps p1
          during those first minutes; then the same OFF/ON at the fixed spot for steady play.
     CP / SPF.  In a dense area or a fight (collision and stage work only cost where there is geometry): CP ON/OFF,
          then SPF ON/OFF. Expect a small CPU W change, no fps change.
     TG.  First set [Patches] L1OnWine = 1 in the ini (or the menu's "L1 on Proton", Save, restart) and check that
          the log says "L1: applied" and "L1 timer sleeps" > 0. Then at the fixed spot: TG OFF / ON / OFF. Read the
          "stats/s TG" line (game ticks/s vs rendered/s and the cap) and the overlay's "(game N Hz)", plus CPU W,
          GPU MHz, fps and the speed factor (must stay 1.00x). Also try dodges / parries and say if anything feels
          late. TG = 0 (or the menu switch) puts everything back at once.
A/B RECIPES - always in your normal environment: the usual power profile, your usual in-game settings, no extra
launch options besides the dinput8 one. Only the mod's own switches change.
   Watts (one patch at a time; W6 stays on; GF first, then ED, then GPU barrier batching):
     1. Fixed spot: stand still at a shrine or a quiet wall, same camera angle every time.
     2. Watch the performance overlay you already use (MangoHud): CPU W, GPU clock (MHz), fps.
     3. Mod menu -> the patch row -> A to switch it OFF. Wait 20 s, note CPU W / GPU MHz / fps.
     4. Switch it ON again. Wait 20 s, note the three values. Repeat OFF/ON 3 times.
     5. A good patch: CPU W down and GPU MHz (or fps) up with it ON, no new stutter.
     6. Note p99 frame time too (MangoHud). The log's "stats wakes/s" line gives the wake counters.
     7. The log has a "stats/s exp:" line every 30 s (W6 waits and average wait in us, PP skips, FPC hit rate, M1
        refreshes, X1/E1 skips); the menu shows the same as "Exp/s". Send the log with your numbers.
   Input latency (same spot, ~60 s per run, TS = 1 in all runs; read the TS row + fps each time):
     A. Baseline: MaxFrameLatency = 0 (game), IK off (menu).
     B. MaxFrameLatency = 2 in the ini, restart, IK off. Does fps go up? Does the TS number go up?
     C. The better of A/B, with IK ON (set IK = 1 and restart). Your v6 run saw no change while GPU-bound; worth a
        retry only where the game reaches its fps cap. The log's "input age K->C" goes
        to well under 1 ms.
   Anything wrong (crash, visual glitch, stutter, a button that misses presses): set that key back to 0 and tell me
   which one.
PROTON FRAME GENERATION GUARD (v1.1.0)
   If you use FrameGenToggle = 2 and the mod switched FG on, the game itself may save FG on when you leave its own
   options menu - and FG on can crash-loop the game under Proton. The mod now puts FRAME_GENERATION back to OFF in
   config.xml when the game exits, and, if the game crashed, at the next start before the game reads its config
   (marker file Nioh3EngineFix.fgmarker next to the mod). The log says "MENU: Proton ..." when it does.
SHADER DUMP SESSION (1.7.1) - please do this once
   This build records the game's shaders ([ShaderSwap] in Nioh3EngineFix.ini: Enabled = 1, DumpMode = 2, LogAll = 1).
   It changes nothing in-game. Boot is a bit slower and the first load writes a few hundred MB of small files.
   1. Start the game, load into a save, play a few minutes (a fight, a menu, a cutscene if you can), exit normally.
   2. In the game folder, zip the folder  Nioh3EngineFix_shaders\dump  (the whole folder).
   3. Send that zip together with Nioh3EngineFix.log.
   To turn it off afterwards: [ShaderSwap] Enabled = 0, and delete Nioh3EngineFix_shaders.

NOTES
   - Online co-op: the ini's VRR line is the frame-timing fix. Use it in single player; set VRR = 0 for online
     co-op until it's tested there.
   - NEW power savers for the Ally (GPU-bound at 25 W, so CPU watts saved go to the GPU):
       WK = 1         skips useless job-system wake-ups (log "stats/s" shows wakes kept / skipped)
       WorkerCap = 10 shrinks the engine's job thread pools (~127 -> ~78 threads). Try 8 for more savings;
                      set 0 to go back to stock if heavy fights stutter more.
   - W3 under Proton now sleeps 1 ms on an empty message queue (fixes the ~24,000 wakes/s from the first test);
     the log prints a "stats/s" line every 30 s with the wake rates.
   - Under Proton the mod skips L1 (frame-limiter sleep) and FG (frame-gen presenter) by default, because Wine
     may not honour the high-resolution timer. You can try L1OnWine = 1 / FGOnWine = 1 and compare.
   - To remove everything: delete dinput8.dll, Nioh3EngineFix.asi/.ini/.log and clear the launch option.
